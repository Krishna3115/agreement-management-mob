import React, { useEffect, useState } from "react";
import { containerApi, containerDocApi } from "../../../services/fieldservice";
import { Box, Plus, Loader2, Trash2, FileText, Upload, Eye } from "lucide-react";

const PRIMARY = "#008d5b";

export default function ManageContainers() {
  const [containers, setContainers] = useState<any[]>([]);
  const [containerNo, setContainerNo] = useState("");
  const [notes, setNotes] = useState("");
  const [stocks, setStocks] = useState<any[]>([]);
  const [draft, setDraft] = useState({ productName: "", receivedQty: "", receivedValue: "" });
  const [saving, setSaving] = useState(false);

  const load = () => containerApi.all().then(setContainers).catch(() => {});
  useEffect(() => { load(); }, []);

  const addStock = () => {
    if (!draft.productName.trim() || !draft.receivedQty) { alert("Product + qty required"); return; }
    setStocks([...stocks, {
      productName: draft.productName,
      receivedQty: Number(draft.receivedQty),
      receivedValue: draft.receivedValue ? Number(draft.receivedValue) : undefined,
    }]);
    setDraft({ productName: "", receivedQty: "", receivedValue: "" });
  };

  const save = async () => {
    if (!containerNo.trim()) { alert("Container No required"); return; }
    if (stocks.length === 0) { alert("Add at least one product"); return; }
    setSaving(true);
    try {
      await containerApi.add({ containerNo, notes, stocks });
      setContainerNo(""); setNotes(""); setStocks([]);
      load();
      alert("Container saved");
    } catch (e: any) { alert(e?.response?.data?.message || "Failed"); }
    finally { setSaving(false); }
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      <div className="px-5 pt-6 pb-8 text-white rounded-b-[28px]" style={{ background: PRIMARY }}>
        <h1 className="text-2xl font-bold">Material Received</h1>
        <p className="text-white/80 text-sm mt-1">Containers, stock & documents</p>
      </div>
      <div className="p-4 space-y-4">
        <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100 space-y-3">
          <h2 className="font-bold flex items-center gap-2"><Box size={18} color={PRIMARY} /> New Container</h2>
          <input className="w-full border rounded-2xl p-3 text-sm" placeholder="Container No. (e.g. OTPU 6691934)"
            value={containerNo} onChange={e => setContainerNo(e.target.value)} />
          <input className="w-full border rounded-2xl p-3 text-sm" placeholder="Notes (optional)"
            value={notes} onChange={e => setNotes(e.target.value)} />

          <div className="border rounded-2xl p-3 bg-slate-50 space-y-2">
            <p className="text-xs font-semibold text-slate-600">Add product received</p>
            <input className="w-full border rounded-xl p-2 text-sm bg-white" placeholder="Product name"
              value={draft.productName} onChange={e => setDraft({ ...draft, productName: e.target.value })} />
            <div className="grid grid-cols-2 gap-2">
              <input type="number" className="border rounded-xl p-2 text-sm bg-white" placeholder="Received qty (boxes)"
                value={draft.receivedQty} onChange={e => setDraft({ ...draft, receivedQty: e.target.value })} />
              <input type="number" className="border rounded-xl p-2 text-sm bg-white" placeholder="Cost value (owner)"
                value={draft.receivedValue} onChange={e => setDraft({ ...draft, receivedValue: e.target.value })} />
            </div>
            <button onClick={addStock} className="w-full py-2 rounded-xl bg-slate-200 text-sm font-semibold flex justify-center gap-2">
              <Plus size={14} /> Add product
            </button>
          </div>

          {stocks.length > 0 && (
            <div className="space-y-2">
              {stocks.map((s, i) => (
                <div key={i} className="flex justify-between items-center p-3 rounded-2xl bg-emerald-50 text-sm">
                  <span className="font-semibold">{s.productName} · {s.receivedQty} boxes</span>
                  <button onClick={() => setStocks(stocks.filter((_, x) => x !== i))} className="text-red-500"><Trash2 size={16} /></button>
                </div>
              ))}
            </div>
          )}

          <button onClick={save} disabled={saving}
            className="w-full py-3 rounded-2xl text-white font-semibold flex justify-center gap-2" style={{ background: PRIMARY }}>
            {saving ? <Loader2 className="animate-spin" size={16} /> : "Save Container"}
          </button>
        </div>

        <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100">
          <h2 className="font-bold mb-3">All Containers ({containers.length})</h2>
          {containers.map(c => (
            <div key={c.id} className="p-3 rounded-2xl bg-slate-50 mb-2">
              <div className="flex justify-between">
                <span className="font-semibold text-sm">{c.containerNo}</span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full ${c.status === "FINISHED" ? "bg-red-100 text-red-700" : "bg-emerald-100 text-emerald-700"}`}>
                  {c.status}
                </span>
              </div>
              {(c.stocks || []).map((s: any) => (
                <div key={s.id} className="text-xs text-slate-500 mt-1">
                  {s.productName}: {Number(s.receivedQty) - Number(s.soldQty)} / {s.receivedQty} left
                </div>
              ))}

              {/* Port documents for this container */}
              <ContainerDocs containerId={c.id} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Per-container document upload + list ───────────────────────────
function ContainerDocs({ containerId }: { containerId: number }) {
  const [docs, setDocs] = useState<any[]>([]);
  const [docName, setDocName] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);

  const load = () => containerDocApi.list(containerId).then(setDocs).catch(() => {});
  useEffect(() => { load(); }, [containerId]);

  const upload = async () => {
    if (!docName.trim() || !file) { alert("Enter document name and choose a file"); return; }
    setBusy(true);
    try {
      await containerDocApi.upload(containerId, docName, file);
      setDocName(""); setFile(null);
      load();
    } catch (e: any) { alert(e?.response?.data?.message || "Upload failed"); }
    finally { setBusy(false); }
  };

  return (
    <div className="mt-3 border-t pt-3">
      <p className="text-[11px] font-semibold text-slate-500 mb-2 flex items-center gap-1">
        <FileText size={12} /> Port Documents
      </p>

      <div className="space-y-2 mb-2">
        <input className="w-full border rounded-xl p-2 text-xs bg-white"
          placeholder="Document name (e.g. Bill of Lading)"
          value={docName} onChange={(e) => setDocName(e.target.value)} />
        <input type="file" accept="application/pdf,image/*"
          className="w-full text-xs"
          onChange={(e) => setFile(e.target.files?.[0] || null)} />
        <button onClick={upload} disabled={busy}
          className="w-full py-2 rounded-xl bg-slate-200 text-xs font-semibold flex justify-center gap-2">
          {busy ? <Loader2 className="animate-spin" size={12} /> : <Upload size={12} />} Upload Document
        </button>
      </div>

      {docs.length === 0 && <p className="text-[10px] text-slate-400">No documents uploaded</p>}
      {docs.map((d) => (
        <div key={d.id} className="flex justify-between items-center text-xs py-1.5 border-b last:border-0">
          <span className="truncate flex-1">{d.docName} <span className="text-slate-400">({d.fileName})</span></span>
          <button onClick={() => containerDocApi.open(d.id)} className="text-blue-600 ml-2 flex items-center gap-1">
            <Eye size={12} /> View
          </button>
        </div>
      ))}
    </div>
  );
}
