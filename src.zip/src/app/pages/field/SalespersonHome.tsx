import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import {
  buyerApi, containerApi, fieldInvoiceApi, paymentApi, expenseApi,
} from "../../../services/fieldservice";
import {
  UserPlus, ShoppingCart, Wallet, Receipt, Plus, Loader2, Mail,
  Download, Trash2, LogOut, TrendingUp, Clock, CheckCircle2, History,
} from "lucide-react";

const PRIMARY = "#008d5b";
type Tab = "sell" | "buyer" | "payments" | "history";
type Period = "today" | "week" | "month";

export default function SalespersonHome() {
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>("sell");

  const logout = () => {
    localStorage.removeItem("jwt_token");
    localStorage.removeItem("user_role");
    navigate("/login");
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <div className="px-5 pt-6 pb-6 text-white rounded-b-[28px]"
        style={{ background: PRIMARY, paddingTop: "calc(env(safe-area-inset-top,0) + 1.5rem)" }}>
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-xl font-bold">Field Sales</h1>
            <p className="text-white/80 text-xs mt-1">Salesperson Panel</p>
          </div>
          <button onClick={logout} className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center">
            <LogOut size={18} />
          </button>
        </div>
      </div>

      <div className="p-4">
        {tab === "sell" && <SellTab />}
        {tab === "buyer" && <BuyerTab />}
        {tab === "payments" && <PaymentsTab />}
        {tab === "history" && <HistoryTab />}
      </div>

      <div className="fixed bottom-0 left-0 right-0 bg-white border-t flex justify-around py-2"
        style={{ paddingBottom: "calc(env(safe-area-inset-bottom,0) + 0.5rem)" }}>
        <NavBtn active={tab === "sell"} onClick={() => setTab("sell")} icon={<ShoppingCart size={20} />} label="Sell" />
        <NavBtn active={tab === "buyer"} onClick={() => setTab("buyer")} icon={<UserPlus size={20} />} label="Buyers" />
        <NavBtn active={tab === "payments"} onClick={() => setTab("payments")} icon={<Wallet size={20} />} label="Payments" />
        <NavBtn active={tab === "history"} onClick={() => setTab("history")} icon={<History size={20} />} label="History" />
      </div>
    </div>
  );
}

function NavBtn({ active, onClick, icon, label }: any) {
  return (
    <button onClick={onClick} className="flex flex-col items-center gap-1 px-3"
      style={{ color: active ? PRIMARY : "#94a3b8" }}>
      {icon}<span className="text-[10px] font-semibold">{label}</span>
    </button>
  );
}

// Period toggle reused across tabs
function PeriodTabs({ value, onChange }: { value: Period; onChange: (p: Period) => void }) {
  const opts: Period[] = ["today", "week", "month"];
  const labels: Record<Period, string> = { today: "Today", week: "This Week", month: "This Month" };
  return (
    <div className="flex bg-slate-100 rounded-2xl p-1 mb-3">
      {opts.map((o) => (
        <button key={o} onClick={() => onChange(o)}
          className={`flex-1 py-2 rounded-xl text-xs font-semibold transition ${value === o ? "text-white" : "text-slate-500"}`}
          style={value === o ? { background: PRIMARY } : {}}>
          {labels[o]}
        </button>
      ))}
    </div>
  );
}

// ════════════════════ SELL TAB ════════════════════
function SellTab() {
  const [buyers, setBuyers] = useState<any[]>([]);
  const [containers, setContainers] = useState<any[]>([]);
  const [buyerId, setBuyerId] = useState("");
  const [vatMode, setVatMode] = useState<"WITH_VAT" | "WITHOUT_VAT">("WITHOUT_VAT");
  const [paymentMode, setPaymentMode] = useState<"CASH" | "CREDIT" | "HALF_CASH_HALF_CREDIT">("CASH");
  const [cashPortion, setCashPortion] = useState("");
  const [lines, setLines] = useState<any[]>([]);
  const [draft, setDraft] = useState({ stockId: "", quantity: "", ratePerBox: "" });
  const [saving, setSaving] = useState(false);
  const [created, setCreated] = useState<any>(null);

  const loadData = () => {
    buyerApi.all().then(setBuyers).catch(() => {});
    containerApi.all().then(setContainers).catch(() => {});
  };
  useEffect(() => { loadData(); }, []);

  const stockOptions: any[] = [];
  containers.forEach((c) => (c.stocks || []).forEach((s: any) => {
    const remaining = Number(s.receivedQty) - Number(s.soldQty);
    if (remaining > 0) stockOptions.push({ stockId: s.id, label: `${c.containerNo} · ${s.productName} (${remaining} left)` });
  }));

  const addLine = () => {
    if (!draft.stockId || !draft.quantity || !draft.ratePerBox) { alert("Select product, qty and rate"); return; }
    const opt = stockOptions.find((o) => String(o.stockId) === String(draft.stockId));
    setLines([...lines, { stockId: Number(draft.stockId), label: opt?.label, quantity: Number(draft.quantity), ratePerBox: Number(draft.ratePerBox) }]);
    setDraft({ stockId: "", quantity: "", ratePerBox: "" });
  };

  const subtotal = lines.reduce((s, l) => s + l.quantity * l.ratePerBox, 0);
  const vat = vatMode === "WITH_VAT" ? subtotal * 0.05 : 0;
  const grand = subtotal + vat;

  const generate = async () => {
    if (!buyerId) { alert("Select a buyer"); return; }
    if (lines.length === 0) { alert("Add at least one item"); return; }
    setSaving(true);
    try {
      const inv = await fieldInvoiceApi.create({
        buyerId: Number(buyerId), vatMode, paymentMode,
        cashPortion: paymentMode === "HALF_CASH_HALF_CREDIT" ? Number(cashPortion || 0) : undefined,
        items: lines.map((l) => ({ stockId: l.stockId, quantity: l.quantity, ratePerBox: l.ratePerBox })),
      });
      setCreated(inv); setLines([]); setBuyerId(""); setCashPortion(""); loadData();
    } catch (e: any) { alert(e?.response?.data?.message || e?.message || "Failed"); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100 space-y-3">
        <h2 className="font-bold flex items-center gap-2"><ShoppingCart size={18} color={PRIMARY} /> New Sale</h2>
        <select className="w-full border rounded-2xl p-3 text-sm" value={buyerId} onChange={(e) => setBuyerId(e.target.value)}>
          <option value="">Select Buyer</option>
          {buyers.map((b) => <option key={b.id} value={b.id}>{b.name}{b.companyName ? ` (${b.companyName})` : ""}</option>)}
        </select>

        <div className="border rounded-2xl p-3 space-y-2 bg-slate-50">
          <p className="text-xs font-semibold text-slate-600">Add product from container</p>
          <select className="w-full border rounded-xl p-2 text-sm bg-white" value={draft.stockId}
            onChange={(e) => setDraft({ ...draft, stockId: e.target.value })}>
            <option value="">Select container · product</option>
            {stockOptions.map((o) => <option key={o.stockId} value={o.stockId}>{o.label}</option>)}
          </select>
          <div className="grid grid-cols-2 gap-2">
            <input type="number" className="border rounded-xl p-2 text-sm bg-white" placeholder="Quantity"
              value={draft.quantity} onChange={(e) => setDraft({ ...draft, quantity: e.target.value })} />
            <input type="number" className="border rounded-xl p-2 text-sm bg-white" placeholder="Rate / box"
              value={draft.ratePerBox} onChange={(e) => setDraft({ ...draft, ratePerBox: e.target.value })} />
          </div>
          <button onClick={addLine} className="w-full py-2 rounded-xl bg-slate-200 text-sm font-semibold flex justify-center gap-2">
            <Plus size={14} /> Add to invoice
          </button>
        </div>

        {lines.length > 0 && (
          <div className="space-y-2">
            {lines.map((l, i) => (
              <div key={i} className="flex justify-between items-center p-3 rounded-2xl bg-emerald-50 text-sm">
                <div className="min-w-0">
                  <div className="font-semibold truncate">{l.label}</div>
                  <div className="text-xs text-slate-500">{l.quantity} × {l.ratePerBox} = {l.quantity * l.ratePerBox}</div>
                </div>
                <button onClick={() => setLines(lines.filter((_, x) => x !== i))} className="text-red-500"><Trash2 size={16} /></button>
              </div>
            ))}
          </div>
        )}

        <div>
          <label className="text-xs text-slate-500">VAT</label>
          <div className="grid grid-cols-2 gap-2 mt-1">
            <button onClick={() => setVatMode("WITHOUT_VAT")}
              className={`py-2 rounded-xl text-sm font-semibold ${vatMode === "WITHOUT_VAT" ? "text-white" : "bg-slate-100 text-slate-600"}`}
              style={vatMode === "WITHOUT_VAT" ? { background: PRIMARY } : {}}>Without VAT</button>
            <button onClick={() => setVatMode("WITH_VAT")}
              className={`py-2 rounded-xl text-sm font-semibold ${vatMode === "WITH_VAT" ? "text-white" : "bg-slate-100 text-slate-600"}`}
              style={vatMode === "WITH_VAT" ? { background: PRIMARY } : {}}>With VAT (5%)</button>
          </div>
        </div>

        <div>
          <label className="text-xs text-slate-500">Payment Mode</label>
          <select className="w-full border rounded-2xl p-3 text-sm mt-1" value={paymentMode}
            onChange={(e) => setPaymentMode(e.target.value as any)}>
            <option value="CASH">Cash</option>
            <option value="CREDIT">Credit (Udhar)</option>
            <option value="HALF_CASH_HALF_CREDIT">Half Cash + Half Credit</option>
          </select>
          {paymentMode === "HALF_CASH_HALF_CREDIT" && (
            <input type="number" className="w-full border rounded-2xl p-3 text-sm mt-2" placeholder="Cash amount paid now"
              value={cashPortion} onChange={(e) => setCashPortion(e.target.value)} />
          )}
        </div>

        <div className="bg-slate-50 rounded-2xl p-3 text-sm space-y-1">
          <div className="flex justify-between"><span>Subtotal</span><span>{subtotal.toFixed(2)}</span></div>
          <div className="flex justify-between"><span>VAT</span><span>{vat.toFixed(2)}</span></div>
          <div className="flex justify-between font-bold" style={{ color: PRIMARY }}><span>Grand Total</span><span>{grand.toFixed(2)}</span></div>
        </div>

        <button onClick={generate} disabled={saving}
          className="w-full py-3 rounded-2xl text-white font-semibold flex justify-center gap-2" style={{ background: PRIMARY }}>
          {saving ? <Loader2 className="animate-spin" size={16} /> : "Generate Invoice"}
        </button>
      </div>

      {created && (
        <div className="bg-white rounded-3xl p-5 shadow-sm border border-emerald-200 space-y-3">
          <h3 className="font-bold text-emerald-700 flex items-center gap-2"><CheckCircle2 size={18} /> Invoice {created.invoiceNo} created</h3>
          <div className="flex gap-2">
            <button onClick={() => fieldInvoiceApi.downloadPdf(created.id)}
              className="flex-1 py-2 rounded-2xl bg-slate-100 text-sm font-semibold flex justify-center gap-2"><Download size={14} /> Download</button>
            <button onClick={async () => { try { await fieldInvoiceApi.sendMail(created.id); alert("Sent to buyer email"); } catch (e: any) { alert(e?.response?.data?.message || "Email failed"); } }}
              className="flex-1 py-2 rounded-2xl text-white text-sm font-semibold flex justify-center gap-2" style={{ background: PRIMARY }}><Mail size={14} /> Email Buyer</button>
          </div>
          <button onClick={() => setCreated(null)} className="w-full py-2 text-slate-500 text-sm">Done</button>
        </div>
      )}
    </div>
  );
}

// ════════════════════ BUYER TAB ════════════════════
function BuyerTab() {
  const [buyers, setBuyers] = useState<any[]>([]);
  const [form, setForm] = useState({ name: "", companyName: "", mobile: "", email: "", address: "" });
  const [saving, setSaving] = useState(false);
  const load = () => buyerApi.all().then(setBuyers).catch(() => {});
  useEffect(() => { load(); }, []);
  const save = async () => {
    if (!form.name.trim()) { alert("Buyer name required"); return; }
    setSaving(true);
    try { await buyerApi.add(form); setForm({ name: "", companyName: "", mobile: "", email: "", address: "" }); load(); alert("Buyer added"); }
    catch (e: any) { alert(e?.response?.data?.message || "Failed"); } finally { setSaving(false); }
  };
  return (
    <div className="space-y-4">
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100 space-y-3">
        <h2 className="font-bold flex items-center gap-2"><UserPlus size={18} color={PRIMARY} /> Add Buyer</h2>
        <input className="w-full border rounded-2xl p-3 text-sm" placeholder="Buyer Name *" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <input className="w-full border rounded-2xl p-3 text-sm" placeholder="Company Name (optional)" value={form.companyName} onChange={(e) => setForm({ ...form, companyName: e.target.value })} />
        <input className="w-full border rounded-2xl p-3 text-sm" placeholder="Mobile No." value={form.mobile} onChange={(e) => setForm({ ...form, mobile: e.target.value })} />
        <input className="w-full border rounded-2xl p-3 text-sm" placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        <textarea className="w-full border rounded-2xl p-3 text-sm" placeholder="Address" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
        <button onClick={save} disabled={saving} className="w-full py-3 rounded-2xl text-white font-semibold flex justify-center gap-2" style={{ background: PRIMARY }}>
          {saving ? <Loader2 className="animate-spin" size={16} /> : <Plus size={16} />} Add Buyer
        </button>
      </div>
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100">
        <h2 className="font-bold mb-3">All Buyers ({buyers.length})</h2>
        <div className="space-y-2">
          {buyers.length === 0 && <p className="text-xs text-slate-400">No buyers yet</p>}
          {buyers.map((b) => (
            <div key={b.id} className="p-3 rounded-2xl bg-slate-50">
              <div className="font-semibold text-sm">{b.name}</div>
              <div className="text-xs text-slate-500">{[b.companyName, b.mobile].filter(Boolean).join(" · ")}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ════════════════════ PAYMENTS TAB (with auto pending) ════════════════════
function PaymentsTab() {
  const [buyers, setBuyers] = useState<any[]>([]);
  const [buyerId, setBuyerId] = useState("");
  const [pending, setPending] = useState<any>(null);
  const [loadingPending, setLoadingPending] = useState(false);
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState<"CASH" | "NETBANKING">("CASH");
  const [referenceId, setReferenceId] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => { buyerApi.all().then(setBuyers).catch(() => {}); }, []);

  // When buyer changes, auto-fetch their pending balance
  useEffect(() => {
    if (!buyerId) { setPending(null); return; }
    setLoadingPending(true);
    buyerApi.pending(Number(buyerId))
      .then(setPending)
      .catch(() => setPending(null))
      .finally(() => setLoadingPending(false));
  }, [buyerId]);

  const totalPending = pending ? Number(pending.totalPending || 0) : 0;
  const payNow = Number(amount || 0);
  const remainingAfter = Math.max(0, totalPending - payNow);
  const paymentType = payNow >= totalPending && totalPending > 0 ? "FULL" : "PARTIAL";

  const submit = async () => {
    if (!buyerId) { alert("Select buyer"); return; }
    if (payNow <= 0) { alert("Enter amount"); return; }
    setSaving(true);
    try {
      await paymentApi.collect({
        buyerId: Number(buyerId), amount: payNow,
        paymentType, method,
        referenceId: method === "NETBANKING" ? referenceId : undefined,
      });
      alert("Payment recorded");
      setAmount(""); setReferenceId("");
      // refresh pending
      const fresh = await buyerApi.pending(Number(buyerId));
      setPending(fresh);
    } catch (e: any) { alert(e?.response?.data?.message || "Failed"); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100 space-y-3">
        <h2 className="font-bold flex items-center gap-2"><Wallet size={18} color={PRIMARY} /> Collect Payment</h2>

        <select className="w-full border rounded-2xl p-3 text-sm" value={buyerId} onChange={(e) => setBuyerId(e.target.value)}>
          <option value="">Select Buyer</option>
          {buyers.map((b) => <option key={b.id} value={b.id}>{b.name}{b.companyName ? ` (${b.companyName})` : ""}</option>)}
        </select>

        {/* AUTO PENDING DISPLAY */}
        {loadingPending && (
          <div className="flex items-center gap-2 text-sm text-slate-500 p-3"><Loader2 className="animate-spin" size={14} /> Loading balance…</div>
        )}

        {pending && !loadingPending && (
          <div className="rounded-2xl p-4 space-y-2" style={{ background: "#f0fdf4" }}>
            <div className="flex justify-between text-sm"><span className="text-slate-500">Total Billed</span><span className="font-semibold">{Number(pending.totalBilled).toFixed(2)}</span></div>
            <div className="flex justify-between text-sm"><span className="text-slate-500">Total Paid</span><span className="font-semibold text-emerald-600">{Number(pending.totalPaid).toFixed(2)}</span></div>
            <div className="flex justify-between text-base font-bold border-t pt-2"><span>Total Pending</span><span className="text-amber-600">{totalPending.toFixed(2)}</span></div>
          </div>
        )}

        {/* Pending invoices breakdown */}
        {pending && pending.pendingInvoices && pending.pendingInvoices.length > 0 && (
          <div className="space-y-1">
            <p className="text-[11px] text-slate-400 uppercase tracking-wide">Unpaid Invoices</p>
            {pending.pendingInvoices.map((inv: any) => (
              <div key={inv.invoiceId} className="flex justify-between text-xs p-2 rounded-xl bg-slate-50">
                <span>{inv.invoiceNo} · {inv.invoiceDate}</span>
                <span className="font-semibold text-amber-600">pending {Number(inv.amountPending).toFixed(2)}</span>
              </div>
            ))}
          </div>
        )}

        {buyerId && totalPending === 0 && !loadingPending && (
          <div className="text-sm text-emerald-600 font-semibold p-2 flex items-center gap-2"><CheckCircle2 size={16} /> No pending balance — fully paid</div>
        )}

        {/* Amount + live calculation */}
        <input type="number" className="w-full border rounded-2xl p-3 text-sm" placeholder="Amount received now"
          value={amount} onChange={(e) => setAmount(e.target.value)} />

        {payNow > 0 && totalPending > 0 && (
          <div className="rounded-2xl p-3 text-sm space-y-1 bg-blue-50">
            <div className="flex justify-between"><span className="text-slate-500">Paying now</span><span className="font-semibold">{payNow.toFixed(2)}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Remaining after</span><span className="font-semibold text-amber-600">{remainingAfter.toFixed(2)}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">This is a</span><span className="font-bold" style={{ color: PRIMARY }}>{paymentType} payment</span></div>
          </div>
        )}

        <select className="w-full border rounded-2xl p-3 text-sm" value={method} onChange={(e) => setMethod(e.target.value as any)}>
          <option value="CASH">Cash</option>
          <option value="NETBANKING">Net Banking</option>
        </select>
        {method === "NETBANKING" && (
          <input className="w-full border rounded-2xl p-3 text-sm" placeholder="Reference ID" value={referenceId} onChange={(e) => setReferenceId(e.target.value)} />
        )}

        <button onClick={submit} disabled={saving}
          className="w-full py-3 rounded-2xl text-white font-semibold flex justify-center gap-2" style={{ background: PRIMARY }}>
          {saving ? <Loader2 className="animate-spin" size={16} /> : "Submit Payment"}
        </button>
      </div>
    </div>
  );
}

// ════════════════════ HISTORY TAB (period + expenses) ════════════════════
function HistoryTab() {
  const [period, setPeriod] = useState<Period>("today");
  const [invoices, setInvoices] = useState<any[]>([]);
  const [expenses, setExpenses] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  // add expense form
  const [expForm, setExpForm] = useState({ description: "", amount: "" });
  const [savingExp, setSavingExp] = useState(false);

  const load = (p: Period) => {
    setLoading(true);
    Promise.all([
      fieldInvoiceApi.range(p).catch(() => []),
      expenseApi.range(p).catch(() => []),
    ]).then(([inv, exp]) => { setInvoices(inv); setExpenses(exp); })
      .finally(() => setLoading(false));
  };
  useEffect(() => { load(period); }, [period]);

  const totalSold = invoices.reduce((s, i) => s + Number(i.grandTotal || 0), 0);
  const totalCollected = invoices.reduce((s, i) => s + Number(i.amountPaid || 0), 0);
  const totalPending = invoices.reduce((s, i) => s + Number(i.amountPending || 0), 0);
  const totalExp = expenses.reduce((s, e) => s + Number(e.amount || 0), 0);

  const addExpense = async () => {
    if (!expForm.description.trim() || !expForm.amount) { alert("Fill description + amount"); return; }
    setSavingExp(true);
    try { await expenseApi.add({ description: expForm.description, amount: Number(expForm.amount) }); setExpForm({ description: "", amount: "" }); load(period); }
    catch (e: any) { alert(e?.response?.data?.message || "Failed"); } finally { setSavingExp(false); }
  };

  return (
    <div className="space-y-4">
      <PeriodTabs value={period} onChange={setPeriod} />

      {/* Summary */}
      <div className="grid grid-cols-2 gap-2">
        <SummaryCard label="Sold" value={totalSold} color="#2563eb" />
        <SummaryCard label="Collected" value={totalCollected} color="#059669" />
        <SummaryCard label="Pending" value={totalPending} color="#d97706" />
        <SummaryCard label="Expenses" value={totalExp} color="#dc2626" />
      </div>
      <div className="bg-white rounded-2xl p-3 text-center shadow-sm">
        <p className="text-[10px] text-slate-400">Net (Sold − Expenses)</p>
        <p className="font-bold text-lg" style={{ color: PRIMARY }}>{(totalSold - totalExp).toFixed(2)}</p>
      </div>

      {/* Add expense */}
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100 space-y-3">
        <h2 className="font-bold flex items-center gap-2"><Receipt size={18} color={PRIMARY} /> Add Expense</h2>
        <input className="w-full border rounded-2xl p-3 text-sm" placeholder="Description"
          value={expForm.description} onChange={(e) => setExpForm({ ...expForm, description: e.target.value })} />
        <input type="number" className="w-full border rounded-2xl p-3 text-sm" placeholder="Amount"
          value={expForm.amount} onChange={(e) => setExpForm({ ...expForm, amount: e.target.value })} />
        <button onClick={addExpense} disabled={savingExp}
          className="w-full py-3 rounded-2xl text-white font-semibold flex justify-center gap-2" style={{ background: PRIMARY }}>
          {savingExp ? <Loader2 className="animate-spin" size={16} /> : <Plus size={16} />} Add Expense
        </button>
      </div>

      {/* Sales list */}
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100">
        <h2 className="font-bold mb-3 flex items-center gap-2"><TrendingUp size={18} color={PRIMARY} /> Sales ({invoices.length})</h2>
        {loading && <div className="flex justify-center py-4"><Loader2 className="animate-spin text-emerald-600" size={20} /></div>}
        {!loading && invoices.length === 0 && <p className="text-xs text-slate-400">No sales in this period</p>}
        <div className="space-y-2">
          {invoices.map((i) => (
            <div key={i.id} className="p-3 rounded-2xl bg-slate-50">
              <div className="flex justify-between">
                <span className="font-semibold text-sm">{i.buyer?.name}</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-200 text-slate-700">{String(i.paymentMode).replace(/_/g, " ")}</span>
              </div>
              <div className="text-xs text-slate-500 mt-1">{i.invoiceNo} · {i.invoiceDate}</div>
              <div className="text-xs text-slate-500">Total {i.grandTotal} · Paid {i.amountPaid} · Pending {i.amountPending}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Expenses list */}
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100">
        <h2 className="font-bold mb-3 flex items-center gap-2"><Receipt size={18} color={PRIMARY} /> Expenses ({expenses.length})</h2>
        {!loading && expenses.length === 0 && <p className="text-xs text-slate-400">No expenses in this period</p>}
        {expenses.map((e) => (
          <div key={e.id} className="flex justify-between text-sm py-2 border-b last:border-0">
            <span>{e.description}<span className="text-[10px] text-slate-400 ml-2">{e.expenseDate}</span></span>
            <span className="font-semibold text-red-500">{e.amount}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function SummaryCard({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="bg-white rounded-2xl p-3 text-center shadow-sm">
      <p className="text-[10px] text-slate-400">{label}</p>
      <p className="font-bold" style={{ color }}>{value.toFixed(0)}</p>
    </div>
  );
}
